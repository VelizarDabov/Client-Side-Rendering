import {html} from '../../node_modules/lit-html/lit-html.js'
import { getAllOffers } from '../data/services.js'

const cardTemplate = (shoes) => html`<li class="card">
<img src="${shoes.imageUrl}" />
<p>
  <strong>Brand: </strong><span class="brand">${shoes.brand}</span>
</p>
<p>
  <strong>Model: </strong
  ><span class="model">${shoes.model}</span>
</p>
<p><strong>Value:</strong><span class="value">${shoes.value}</span>$</p>
<a class="details-btn" href="">Details</a>
</li>`
const catalogTemplate = (offers) => html`
<section id="dashboard">
<h2>Collectibles</h2>

${offers.length > 0 ? offers.map(cardTemplate) : html`<h2>There are no items added yet.</h2>`}
 
</section>`
export async function catalogPage(ctx){
    const offers = await getAllOffers()
    ctx.render(catalogTemplate(offers))
}