import{post, get, put, del} from './api.js';

const endpoints = {
    catalog:'/data/shoes?sortBy=_createdOn%20desc',
    byId: '/data/shoes/'
}

export async function getAllOffers(){
    return get(endpoints.catalog)
}
export async function createOffer(data){
    return post(endpoints.catalog, data)
    
};
export async function updateOffer(id, data){
    return put(endpoints.byId + id, data)
}
export async function deleteOffers(id){
    return del(endpoints.byId + id)
}
export async function getShoeById(id){
    return get(endpoints.byId + id);

}
export async function postApplication(shoeId) {
    return await post(endpoints.byId, { shoeId: shoeId })
  }
  export async function search(query) {
    return await get(`/data/shoes?where=brand%20LIKE%20%22${query}%22`);
  }