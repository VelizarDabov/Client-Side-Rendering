import{post, get, put, del} from './api.js';

const endpoints = {
    getGames: `/data/games?sortBy=_createdOn%20desc&distinct=category`,
    post:`/data/games`,
    postById: `/data/games/`
}

export async function getAllGames(){
    return await get(endpoints.getGames);
}
export function createPost(data){
    return post(endpoints.postById, data)
}
export async function getGameId(id){
    return get(`/data/games/${id}`)
}
export async function deleteGameById(id){
    return del(`/data/games/${id}`)
}
export async function  editGameById(id, data){
    return put(`/data/games/${id}`, data)
}