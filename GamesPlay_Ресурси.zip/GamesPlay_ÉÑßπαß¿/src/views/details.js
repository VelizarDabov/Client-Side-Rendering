import { html } from '../../node_modules/lit-html/lit-html.js';
import { getGameId, deleteGameById} from '../data/services.js'
import { getUserData } from '../util.js';

const detailsTemplate = (game, isOwner, onDelete, isLoggedIn) => html`
<section id="game-details">
            <h1>Game Details</h1>
            <div class="info-section">

                <div class="game-header">
                    <img class="game-img" src="${game.imageUrl}" />
                    <h1>${game.title}</h1>
                    <span class="levels">MaxLevel: ${game.maxLevel}</span>
                    <p class="type">${game.category}</p>
                </div>

                <p class="text">
${game.summary}

                </p>
                
              


                <div class="buttons">
                ${isOwner ? html` <a href="/edit/${game._id}" class="button">Edit</a>
                    <a href="javascript:void(0)"  @click=${onDelete} class="button">Delete</a>` : ''}
                    <div class="details-comments">
                <h2>Comments:</h2>
                ${isLoggedIn ? html`
                <p>Content: </p>
       
           
                <p>Content: </p>
            
        ` : html`<p class="no-comment">No comments.</p>
        </div>`}
       
                
                </div>
                ${isOwner ? html`<article class="create-comment">
                <label>Add new comment:</label>
                <form class="form">
                    <textarea name="comment" placeholder="Comment......"></textarea>
                    <input class="btn submit" type="submit" value="Add Comment">
                </form>
            </article>` : ''}
            </div>

        </section>`

        export async function detailsPage(ctx) {
            const gameId = ctx.params.id;
            const game = await getGameId(gameId);
            const userId = getUserData() ?._id 
          //  const user = ctx.user
        console.log(gameId);
        console.log(game);
            const isOwner = userId == game._ownerId;
           let isLoggedIn = userId != null;
           ctx.render(detailsTemplate(game, isOwner, onDelete, isLoggedIn));
            async function onDelete() {
                const confirmed = confirm('Are you sure?');
                if (confirmed) {
                    await deleteGameById(gameId);
                    ctx.page.redirect('/');
                }
            }
        }