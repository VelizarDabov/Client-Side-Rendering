import page from '../node_modules/page/page.mjs';
import { catalogView } from './views/catalogView.js';
import { createView } from './views/createView.js';
import { detailsView } from './views/detailsView.js';
import { loginView } from './views/loginView.js';
import { logoutView } from './views/logoutView.js';
import { registeView } from './views/registeView.js';
import { editView } from './views/editView.js';
import { myFurnitureView } from './views/myFurnitureView.js';

//update nav bar
export function updateNav(){
    const userNav = document.getElementById('user');
    const guestNav = document.getElementById('guest');
    if(sessionStorage.getItem('userData')== null){
        userNav.style.display = 'none';
        guestNav.style.display = 'inline-block';
    }else{
        userNav.style.display = 'inline-block';
        guestNav.style.display = 'none';
    }
}
//start the app
updateNav()
document.getElementById('logoutBtn').addEventListener('click',logoutView)
page('/',catalogView);
page('/login',loginView);
page('/register',registeView);
page('/create', createView);
page('/edit/:id', editView);
page('/details/:id', detailsView);
page('/my-publications', myFurnitureView);

page.start();