import{post, get, put, del} from './api.js';

const endpoints = {
    catalog:'/data/pets?sortBy=_createdOn%20desc&distinct=name',
    post:'/data/pets',
    getById: '/data/pets/',
getDonation: `/data/donation`
}

export async function getCatalog(){
    return get(endpoints.catalog);
}
export function createPost(data){
    return post(endpoints.post, data)
}
export async function getPetById(id){
    return get(`/data/pets/${id}`)
}
export async function deletePetById(id){
    return  del(endpoints.getById + id)
}
export async function getTotalDonationCount(petId){
    return get(`/data/donation?where=petId%3D%22${petId}%22&distinct=_ownerId&count`)
}
export async function donationPet(petId){
    return post(endpoints.getDonation, petId)
}
export async function didUserDonation(petId, userId){
    return get(`/data/donation?where=petId%3D%22${petId}%22%20and%20_ownerId%3D%22${userId}%22&count`)
}
export async function getMyPet(petId){
    return get(`/data/pets?where=_ownerId%3D%22${petId}%22&sortBy=_createdOn%20desc`)
}
export async function editPetById(id, data){
    return put(`/data/pets/${id}`, data)
}
