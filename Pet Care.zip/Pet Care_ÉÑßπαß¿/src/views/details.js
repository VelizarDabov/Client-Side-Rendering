import { html } from '../../node_modules/lit-html/lit-html.js';
import { deletePetById, getPetById, getTotalDonationCount, didUserDonation, donationPet } from '../data/services.js'
import { getUserData } from '../util.js';
const detailsTamplate = (pet, isOwner, onDelete, isLoggedIn, totalDonationCount, onClickDonation, didUserDonate) => html`<section id="detailsPage">
    <div class="details">
        <div class="animalPic">
            <img src="${pet.image}">
        </div>
        <div>
            <div class="animalInfo">
                <h1>Name: ${pet.name}</h1>
                <h3>Breed: ${pet.breed}</h3>
                <h4>Age: ${pet.age}</h4>
                <h4>Weight: ${pet.weight}</h4>
                <h4 class="donation">Donation: ${totalDonationCount * 100}$</h4>
            </div>
            
            <div class="actionBtn">
                ${isOwner ? html`<a href="/edit/${pet._id}" class="edit">Edit</a>
                <a href="javascript:void(0)" @click=${onDelete} class="remove">Delete</a>
                ` : ''}

                ${(() => {
                if (didUserDonate == 0) {
                    if (isLoggedIn && !isOwner) {        
                        return html`<a href="javascript:void(0)" class="donate"
                    @click=${onClickDonation}>Donate</a>`
                    }
                }
            })()}

            </div>
        </div>
    </div>
</section>`;
export async function detailsPage(ctx) {
    const petId = ctx.params.id;
    const pet = await getPetById(petId);
    const userId = getUserData() ?._id 
    const user = ctx.user

    const isOwner = userId == pet._ownerId;
   let isLoggedIn = userId != null;
    let totalDonationCount;
    let didUserDonate;

    if (userId) {
        didUserDonate = await didUserDonation(petId, userId);
    }

    

    totalDonationCount = await getTotalDonationCount(petId);
    ctx.render(detailsTamplate(pet, isOwner, onDelete, isLoggedIn, totalDonationCount, onClickDonation, didUserDonate));

    async function onClickDonation() {
        const donation = {
            petId,
        }
        await donationPet(donation);

        totalDonationCount = await getTotalDonationCount(petId);
        didUserDonate = await didUserDonation(petId, userId);
        ctx.render(detailsTamplate(pet, isOwner, onDelete, isLoggedIn, totalDonationCount, onClickDonation, didUserDonation));
    }

    async function onDelete() {
        const confirmed = confirm('Are you sure?');
        if (confirmed) {
            await deletePetById(petId);
            ctx.page.redirect('/');
        }
    }
}