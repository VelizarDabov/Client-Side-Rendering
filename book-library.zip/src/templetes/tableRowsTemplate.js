import {html} from '../../node_modules/lit-html/lit-html.js';
export const tableRowsTemplates = (context) => html`${context.books.map((b)=>
     bookRowTemlate(b, context.deleteFunction, context.editBtnHandler))}`


const bookRowTemlate = (book,deleteFunction, updateHandler) =>{
    return html`
    <tr>
        <td>${book.title}</td>
        <td>${book.author}</td>
  
        <td>
           
        <button  @click=${updateHandler.bind(null, book._id)}>Edit</button>
            <button @click=${deleteFunction.bind( null, book._id)}>Delete</button>
       </td>
    </tr>
    `;
}