import {html} from '../../node_modules/lit-html/lit-html.js';

export const loadBtnTemplate= () => html `<button id="loadBooks">LOAD ALL BOOKS </button>`;